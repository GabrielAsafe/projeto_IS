using System.Text.Json.Serialization;

namespace middleware.Models;

public class ChannelRequest
{
    [JsonPropertyName("resource-name")]
    public string ResourceName { get; set; } = "";

    [JsonPropertyName("resource-desc")]
    public string ResourceDesc { get; set; } = "";
}