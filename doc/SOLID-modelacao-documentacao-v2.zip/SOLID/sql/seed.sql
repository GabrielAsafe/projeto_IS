-- SAMPLE DATA: demonstrativo de modelação, não base de dados de implementação pronta.
-- Recriar com schema.sql antes de executar seed.sql.
PRAGMA foreign_keys = ON;
INSERT INTO applications(resource_name,resource_desc,created_at)
VALUES('app1','Application required by assignment','2026-10-27T08:00:00');
INSERT INTO channels(application_id,resource_name,resource_desc,created_at)
VALUES((SELECT id FROM applications WHERE resource_name='app1'),'channel1','Channel required by assignment','2026-10-27T08:00:00');
INSERT INTO data_records(channel_id,resource_name,content_type,content,created_at,expires_at)
VALUES((SELECT ch.id FROM channels ch JOIN applications app ON ch.application_id=app.id WHERE app.resource_name='app1' AND ch.resource_name='channel1'),'dr1','application/json','{"humidity":45}','2026-10-27T08:00:00',NULL);
INSERT INTO subscriptions(channel_id,resource_name,evt,endpoint,created_at,expires_at)
VALUES((SELECT ch.id FROM channels ch JOIN applications app ON ch.application_id=app.id WHERE app.resource_name='app1' AND ch.resource_name='channel1'),'sub1',1,'http://localhost:9090/notifications','2026-10-27T08:00:00',NULL);
