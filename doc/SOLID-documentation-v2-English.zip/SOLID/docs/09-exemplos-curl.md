# 09 — cURL examples by resource

**Test examples for the API to be implemented; these are not execution results.** They use the interface designed in `05-contrato-rest.md`. Run after starting the server on port 8765.

```bash
BASE='http://localhost:8765/api/solid'

# Application: CREATE / READ / UPDATE / DISCOVER / DELETE
curl -i -X POST "$BASE" -H 'Content-Type: application/json' \
  -d '{"res-type":"application","resource-name":"app1","resource-desc":"IoT"}'
curl -i "$BASE/app1"
curl -i -X PUT "$BASE/app1" -H 'Content-Type: application/json' \
  -d '{"res-type":"application","resource-name":"app1","resource-desc":"IoT updated"}'
curl -i "$BASE" -H 'solid-discovery: application'

# Channel: CREATE / READ / UPDATE / DISCOVER
curl -i -X POST "$BASE/app1" -H 'Content-Type: application/json' \
  -d '{"res-type":"channel","resource-name":"channel1","resource-desc":"Humidity"}'
curl -i "$BASE/app1/channel1"
curl -i -X PUT "$BASE/app1/channel1" -H 'Content-Type: application/json' \
  -d '{"res-type":"channel","resource-name":"channel1","resource-desc":"Updated humidity"}'
curl -i "$BASE/app1" -H 'solid-discovery: channel'

# Data-record: CREATE / READ / DISCOVER (no UPDATE)
curl -i -X POST "$BASE/app1/channel1" -H 'Content-Type: application/json' \
  -d '{"res-type":"data-record","resource-name":"dr1","content-type":"text/plain","content":"45","dt-expiration":null}'
curl -i "$BASE/app1/channel1/dr1"
curl -i "$BASE/app1" -H 'solid-discovery: data-record'

# Subscription: CREATE / READ / DISCOVER (no UPDATE)
curl -i -X POST "$BASE/app1/channel1" -H 'Content-Type: application/json' \
  -d '{"res-type":"subscription","resource-name":"sub1","evt":1,"endpoint":"http://localhost:9090/notifications","dt-expiration":null}'
curl -i "$BASE/app1/channel1/subs/sub1"
curl -i "$BASE/app1" -H 'solid-discovery: subscription'

# Confirm that a normal GET does not list all resources
curl -i "$BASE/app1/channel1"
# Confirm empty scope and HTTP 200 status
curl -i "$BASE/app1/channel1/dr1" -H 'solid-discovery: data-record'

# Deletes: bottom-up order
curl -i -X DELETE "$BASE/app1/channel1/dr1"
curl -i -X DELETE "$BASE/app1/channel1/subs/sub1"
curl -i -X DELETE "$BASE/app1/channel1"
curl -i -X DELETE "$BASE/app1"
```

## Additional coverage needed in the report

- `POST` without `resource-name` ⇒ response with a generated name.
- `POST` with a duplicate name ⇒ response with a different valid name.
- `POST` invalid request without `res-type`.
- Rejection of `PUT/PATCH` for `data-record` and `subscription`.
- `evt` 0, 3 or string ⇒ invalid as per §2.4.
- `dt-expiration` past, future, empty, and invalid.
- Recursion of `solid-discovery` and subscription paths containing `/subs/`.
- HTTP and MQTT events for creation/deletion and payload formats.

The cURL commands section of the final report must reflect the **actually implemented** routes/codes/statuses, and its commands must be executed before submission.
