# 17 — Modeling and architecture rationale (v2)

## 1. Sources and degree of certainty

- **[REQUIREMENT]** Brief §2 specifies four resource types, a hierarchy of at most three levels, exact JSON property names, REST/JSON, and header-based discovery.
- **[REQUIREMENT]** Brief §§2 and 2.4 specify .NET 10, SQLite, port 8765, timestamps and expiration, HTTP/MQTT notifications, and Swagger/OpenAPI.
- **[REQUIREMENT]** Brief §4 requires independent Sensor and Valve apps communicating **only through the middleware**, measurements every second, a threshold rule, and XML/XSD.
- **[PROPOSAL]** Modular monolith with API / Application / Domain / Infrastructure separation; neither microservices nor complete Clean Architecture are required.

## 2. Why a modular monolith rather than microservices?

There is one contract (`/api/solid`), the required persistence is SQLite, and there are only four closely related persisted types. Separating services into processes would complicate consistency, deployment, discovery, and notification handling without a benefit mandated by the brief. **Modular** does not mean all responsibilities are mixed together: modules are classes/components within the same API process. **Sensor** and **Valve** are independent applications (other processes), as required by §4.

## 3. Why these four resources and four tables?

The brief's tree defines the aggregates and their relationships: Application → Channel → (DataRecord, Subscription). Four tables simplify type-specific constraints, foreign keys, and deletion; one generic table would be possible but would have many null fields and conditional validations. `subs` is only a virtual URI node; it **does not** create a fifth entity.

## 4. Why DTOs, and why `res-type`?

The creation API addresses **the parent**. Within the same channel, `POST /api/solid/{app}/{channel}` can create either a `data-record` or a `subscription`; the **mandatory** JSON field `res-type` discriminates the request. The server parses the envelope and validates a **concrete DTO**, e.g., `CreateDataRecordDto` or `CreateSubscriptionDto`. This is one possible implementation pattern; having a single middleware **does not itself require** the discriminator. The discriminator comes from the **public contract** in the brief. DTOs isolate JSON with hyphenated keys from SQL entities with private `id` and FKs.

## 5. Why separate services?

- `ResourceApplicationService`: creation, name validation, invariants, update/deletion.
- `DiscoveryService`: recursive lookup and projection of *paths*, without changing data.
- `NotificationCoordinator`: `evt` filtering, event data, and HTTP/MQTT selection after persistence.
- `ExpirationWorker`: internal TTL maintenance; **not** measurement polling by the Valve.
- `Repositories`: SQLite access contract, which is not a public object.

These are conceptual names; the solution may use fewer projects/classes depending on class coverage.

## 6. Diagram separation

- `01-diagrama-classes`: **domain**, without services.
- `02-diagrama-er`: tables/PK/FK (database perspective).
- `03-arquitetura-componentes`: processes and modules.
- `10-diagrama-servicos`: code dependencies.
- `11-diagrama-dtos`: JSON/domain boundary and discriminator.
- `05`, `07`, `12`: temporal order and event contracts.
- `09`, `13`: cleanup and deletion processes.

## 7. Risks that remain decisions, not facts

`evt=both` vs `evt` 1/2 (Q-01); names across different types under the same parent (Q-03); cascades (Q-04); expiration notifications (Q-05); MQTT `endpoint` without a protocol field (Q-08); retry/QoS (Q-13); technologies allowed in class (Q-14). These are identified in `13-duvidas-e-decisoes.md` to avoid silent assumptions.

## 8. Modeling status

This material is **design and an SQL prototype**, not a working implementation of the API, broker, or simulators. The final result can only be validated through real tests and instructor feedback.
