# 03 — Proposed component architecture

**Status: [PROPOSAL], not an implementation.**

```mermaid
flowchart TB
    Sensor[Moisture Sensor App] -->|REST POST 1/s| REST
    Other[Other clients] -->|HTTP JSON| REST
    subgraph MW[SOLID Middleware .NET 10 - one modular process]
      REST[API layer - /api/solid routes, DTOs, Swagger]
      Resource[ResourceApplicationService]
      Discovery[DiscoveryService]
      Expiration[ExpirationWorker]
      Outbox[NotificationCoordinator - after persistence]
      Repo[Repository interfaces / unit of work]
      Persist[SQLite repositories]
      HTTP[HTTP notification adapter]
      MQTT[MQTT notification adapter]
      REST --> Resource
      REST --> Discovery
      Resource --> Repo
      Discovery --> Repo
      Expiration --> Resource
      Repo --> Persist
      Persist --> DB[(SQLite)]
      Resource -.->|post-commit event| Outbox
      Outbox --> HTTP
      Outbox --> MQTT
    end
    HTTP -->|HTTP POST| Valve[Water Valve App]
    MQTT -->|publish| Broker[MQTT Broker]
    Broker -->|push| Valve
    Valve --> XML[XML log validated against XSD]
    REST --> Swagger[Swagger / OpenAPI]
```

**Separation:** the REST layer handles protocol/DTOs; the application layer orchestrates use cases; the domain contains invariants; infrastructure implements SQLite and transports. Sensor/Valve applications are **independent processes** and only connect through SOLID. They are not internal microservices.

**Note:** the post-commit event arrow expresses logical order, not a guarantee of reliable delivery. A persistent outbox is only an **optional alternative**. Contract and reliability: `../07-notificacoes-e-expiracao.md`.
