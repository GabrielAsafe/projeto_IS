# 05 — Data-record creation and notification

**Status: [PROPOSAL], not an implementation.**

```mermaid
sequenceDiagram
    autonumber
    actor Client
    participant API as API + DTO dispatch
    participant App as ResourceApplicationService
    participant Repo as Repositories
    participant DB as SQLite
    participant Notif as NotificationCoordinator
    participant Adapter as HTTP / MQTT adapters
    Client->>API: POST /api/solid/app1/channel1 (res-type=data-record)
    API->>API: Validate res-type + CreateDataRecordDto
    API->>App: CreateDataRecord(channel, dto)
    App->>Repo: Check parent, name, and constraints
    Repo->>DB: INSERT + COMMIT
    DB-->>Repo: Persisted record
    Repo-->>App: Persisted entity
    App-->>API: ResourceResponseDto
    API-->>Client: 201 + complete representation
    App-->>Notif: RecordCreated (after COMMIT)
    Notif->>Repo: Find subscriptions evt=1
    Repo-->>Notif: Channel recipients
    loop For each recipient
      Notif->>Adapter: Send NotificationDto
    end
    Note over App,Adapter: No durable delivery guarantee in the minimal proposal
```

`res-type` is a mandatory **discriminator** in the JSON body; it does not imply that there is only one entity or a single DTO class. The server selects the specific DTO from the envelope. Persistence precedes event emission to avoid notifying data that has not yet been saved. The timing of the HTTP response relative to asynchronous delivery must be defined/tested; delivery is shown here logically after commit, with no real-time promise.
