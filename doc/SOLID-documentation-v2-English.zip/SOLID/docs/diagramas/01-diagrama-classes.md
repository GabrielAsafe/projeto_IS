# 01 — Domain model (without services)

**Status: [PROPOSAL], not an implementation.**

```mermaid
classDiagram
    direction TB
    class Application {
        +string ResourceName
        +string ResourceDesc
        +DateTime CreatedAt
    }
    class Channel {
        +string ResourceName
        +string ResourceDesc
        +DateTime CreatedAt
    }
    class DataRecord {
        +string ResourceName
        +string ContentType
        +string Content
        +DateTime CreatedAt
        +DateTime? ExpiresAt
    }
    class Subscription {
        +string ResourceName
        +int EventType
        +string Endpoint
        +DateTime CreatedAt
        +DateTime? ExpiresAt
    }
    Application "1" *-- "0..*" Channel : channels
    Channel "1" *-- "0..*" DataRecord : records
    Channel "1" *-- "0..*" Subscription : subscriptions
```

**Source:** §2 of the brief. The four types have exact public names `application`, `channel`, `data-record`, and `subscription`. Only **domain entities** appear here, not Controllers/Services/DTOs/SQLite IDs. PascalCase names are internal to the code; `res-type` is a property of the JSON contract and does not require an SQL column per entity.

**Cardinality:** `0..*` channels was modeled to allow atomic creation of an application that does not yet contain channels, whereas the brief describes the desired state as 1..N. This tension is recorded in Q-18; do not conceal the initial configuration period.

**Composition:** suggests strong hierarchical ownership, but **does not by itself determine** cascade deletion or notification policies. See `19-politica-nomes-e-cascatas.md`.
