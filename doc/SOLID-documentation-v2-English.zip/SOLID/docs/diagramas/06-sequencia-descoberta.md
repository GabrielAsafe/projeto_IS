# Discovery sequence

**Proposed model**, not a completed implementation.

```mermaid
sequenceDiagram
    autonumber
    actor Client
    participant API as REST API
    participant Discovery as DiscoveryService
    participant DB as SQLite
    Client->>API: GET /api/solid/app1 (solid-discovery: subscription)
    API->>Discovery: Discover descendants of type subscription
    Discovery->>DB: Select matching descendants under app1
    DB-->>Discovery: Internal entities + their parent names
    Discovery-->>API: ["/api/solid/app1/channel1/subs/sub1"]
    API-->>Client: 200 application/json string[]
    Note over API,Client: GET without header returns single resource
```

The discovery operation does not return entities or SQLite IDs: it returns **resource paths** in JSON.
