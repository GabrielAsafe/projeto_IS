# 13 — Resource deletion and events

**Status: [PROPOSAL], not an implementation.**

```mermaid
flowchart TD
    Call[Public DELETE or expiration cleanup] --> Locate[Identify resource by name/path]
    Locate --> Child{Resource type}
    Child -->|data-record| Snapshot[Capture snapshot + path before DELETE]
    Child -->|subscription| RemoveSub[Remove subscription without data-record event]
    Child -->|application/channel| Desc{Is cascade Q-04 confirmed?}
    Desc -->|Yes| Enumerate[Enumerate descendant records if policy requires events]
    Desc -->|No| Reject[Reject or apply agreed strategy]
    Snapshot --> Commit[Remove and commit transaction]
    RemoveSub --> Commit
    Enumerate --> Commit
    Commit --> Notify{Should deletion event be emitted? Q-05}
    Notify -->|Yes| Dispatch[Send evt=2 after commit with snapshot]
    Notify -->|No/to be decided| Log[Record behavior and test]
```

Deleting a record requires preserving its complete representation **before** deletion because the notification must include the affected resource. `ON DELETE CASCADE` in SQLite does not automatically generate external notifications; these must be coordinated by the application if required by policy. Questions Q-04/Q-05 remain explicit.
