# 07 — Event-driven communication in irrigation

**Status: [PROPOSAL], not an implementation.**

```mermaid
sequenceDiagram
    autonumber
    actor User
    participant Valve as Water Valve App
    participant Broker as MQTT Broker (when used)
    participant API as SOLID Middleware
    participant Sensor as Moisture Sensor App
    participant XML as XML file / XSD
    User->>Valve: Set threshold T
    Valve->>API: POST subscription (evt=1)
    API-->>Valve: Resource created
    loop Every second on the SENSOR
      Sensor->>API: POST data-record humidity H (0..100)
      API-->>Sensor: 201 JSON (assigned name)
      alt HTTP delivery
        API-->>Valve: HTTP POST NotificationDto
      else MQTT delivery
        API->>Broker: publish to channel topic
        Broker-->>Valve: event message
      end
      Valve->>XML: Append notification; validate XML against XSD
      alt H below T
        Valve->>Valve: State ON
      else H greater than or equal to T
        Valve->>Valve: State OFF
      end
    end
    Note over Valve,Sensor: No valve polling or direct sensor-valve connection
```

Two alternative **delivery** paths are shown, not two mandatory sends per measurement to the same subscription. In practice, the Valve uses the configured transport. If a notification does not provide enough information, a GET **triggered by the notification** is permitted as an integration choice; it is not polling. XML/XSD is generated/validated by the Valve.
