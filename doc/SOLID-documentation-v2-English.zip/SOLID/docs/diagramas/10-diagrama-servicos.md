# 10 — Services and dependencies (without business entities)

**Status: [PROPOSAL], not an implementation.**

```mermaid
classDiagram
    direction LR
    class SolidResourceController {
        +Post(path, json)
        +Get(path, discoveryHeader)
        +Put(path, json)
        +Delete(path)
    }
    class CreateDtoResolver {
        +Resolve(resType, json)
    }
    class ResourceApplicationService {
        +Create(parentPath, dto)
        +Retrieve(targetPath)
        +Update(targetPath, dto)
        +Delete(targetPath)
    }
    class DiscoveryService {
        +Discover(scopePath, resType)
    }
    class IResourceRepository {
        <<interface>>
        +Find(path)
        +Create(resource)
        +Delete(resource)
        +FindDescendants(scope, type)
    }
    class NotificationCoordinator {
        +OnRecordCreated(record)
        +OnRecordDeleted(record)
    }
    class INotificationTransport {
        <<interface>>
        +Send(subscription, event)
    }
    class HttpNotificationAdapter
    class MqttNotificationAdapter
    class ExpirationWorker {
        +ExecuteAsync()
    }
    SolidResourceController --> CreateDtoResolver
    SolidResourceController --> ResourceApplicationService
    SolidResourceController --> DiscoveryService
    ResourceApplicationService --> IResourceRepository
    DiscoveryService --> IResourceRepository
    ResourceApplicationService ..> NotificationCoordinator
    NotificationCoordinator --> IResourceRepository
    NotificationCoordinator --> INotificationTransport
    HttpNotificationAdapter ..|> INotificationTransport
    MqttNotificationAdapter ..|> INotificationTransport
    ExpirationWorker --> ResourceApplicationService
```

This is a **responsibilities and dependencies diagram**, not a process diagram. Interfaces/repositories are [PROPOSAL]; this exact number of classes is not mandatory. `ResourceApplicationService` validates rules; adapters understand HTTP/MQTT but not the irrigation business rule. `ExpirationWorker` can call a dedicated removal use case rather than execute SQL directly, to avoid bypassing rules/events.
