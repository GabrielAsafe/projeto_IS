# Resource tree and URIs

**Proposed model**, not a completed implementation.

```mermaid
flowchart TD
    Root["/api/solid"] --> App["/app1 — application"]
    App --> Ch["/app1/channel1 — channel"]
    Ch --> Rec["/app1/channel1/dr1 — data-record"]
    Ch -.-> SubNode["/app1/channel1/subs — virtual"]
    SubNode --> Sub["/app1/channel1/subs/sub1 — subscription"]
    style SubNode stroke-dasharray: 5 5
```

`subs` is a **virtual, non-persisted** addressing segment. Records and subscriptions are created with `POST /api/solid/app1/channel1`, distinguished by the `res-type` field. The figure shows a minimal example, not the complete global cardinality.
