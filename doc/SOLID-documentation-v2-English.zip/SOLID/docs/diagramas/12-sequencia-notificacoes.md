# 12 — Notification contract and delivery paths

**Status: [PROPOSAL], not an implementation.**

```mermaid
sequenceDiagram
    autonumber
    participant App as ResourceApplicationService
    participant DB as SQLite
    participant Notify as NotificationCoordinator
    participant Http as HTTP Adapter
    participant Mqtt as MQTT Adapter
    participant Broker as MQTT Broker
    participant Target as External Subscriber
    App->>DB: Persist data-record
    DB-->>App: COMMIT OK
    App->>Notify: Event + record snapshot + full path
    Notify->>DB: Find channel subscriptions with matching evt
    DB-->>Notify: Subscription list
    loop Each subscription
      alt endpoint HTTP URL
        Notify->>Http: NotificationDto and URL
        Http->>Target: HTTP POST JSON
      else endpoint MQTT broker
        Notify->>Mqtt: Broker URI + topic derived from channel
        Mqtt->>Broker: PUBLISH topic api/solid/app/channel
        Broker->>Target: Deliver event
      end
    end
    Note over Notify,Target: Retries QoS and failures: question Q-13 remains open
```

The **method of distinguishing** HTTP and MQTT from `endpoint` (without an additional public property) remains to be agreed. The MQTT topic is derived from the channel path, not stored in `endpoint`. Delivery after commit does not imply an outbox or protection against loss in a crash; see `../07-notificacoes-e-expiracao.md`.
