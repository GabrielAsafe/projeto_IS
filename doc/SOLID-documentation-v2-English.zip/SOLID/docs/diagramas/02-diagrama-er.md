# 02 — SQLite ER model

**Status: [PROPOSAL], not an implementation.**

```mermaid
erDiagram
    APPLICATIONS ||--o{ CHANNELS : contains
    CHANNELS ||--o{ DATA_RECORDS : contains
    CHANNELS ||--o{ SUBSCRIPTIONS : contains
    APPLICATIONS {
        integer id PK
        string resource_name UK
        string resource_desc
        string created_at
    }
    CHANNELS {
        integer id PK
        integer application_id FK
        string resource_name
        string resource_desc
        string created_at
    }
    DATA_RECORDS {
        integer id PK
        integer channel_id FK
        string resource_name
        string content_type
        string content
        string created_at
        string expires_at
    }
    SUBSCRIPTIONS {
        integer id PK
        integer channel_id FK
        string resource_name
        integer evt
        string endpoint
        string created_at
        string expires_at
    }
```

**Source:** hierarchy relationships from §2. The database adds strictly internal PKs/FKs (§2.1). `subs` does not exist in the database; it is a **virtual** route node. The provisional v2 policy prohibits name collisions **between** `DATA_RECORDS` and `SUBSCRIPTIONS` in the same channel using triggers (Mermaid ER cannot express triggers); see `../../sql/schema.sql`. IDs never appear in URLs or JSON.
