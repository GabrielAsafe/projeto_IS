# 09 — Expiration and cascades

**Status: [PROPOSAL], not an implementation.**

```mermaid
flowchart TD
    Wake([BackgroundService / PeriodicTimer]) --> Find[Find expired records/subscriptions]
    Find --> Any{Are any resources past expiration?}
    Any -->|No| Wait([Wait for next cycle])
    Any -->|Yes| Remove[Remove resources in a transaction]
    Remove --> Type{Was it a data-record?}
    Type -->|Yes| Policy{Is policy Q-05 confirmed?}
    Type -->|No| Wait
    Policy -->|Automatic removal notifies| Event[Publish deletion event after commit]
    Policy -->|No confirmed obligation| Record[Record decision + test]
    Event --> Wait
    Record --> Wait
```

**[REQUIREMENT]** Automatic expiration of data-record/subscription; **[PROPOSAL]** worker inside the middleware. The loop maintains the database; it is not the Valve detecting measurements. Record removals due to expiration, direct DELETE, or cascade must have an event policy defined in `19-politica-nomes-e-cascatas.md`.
