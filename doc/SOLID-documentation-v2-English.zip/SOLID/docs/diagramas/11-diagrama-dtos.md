# 11 — DTOs, res-type, and JSON mapping

**Status: [PROPOSAL], not an implementation.**

```mermaid
classDiagram
    direction TB
    class CreateResourceEnvelope {
        +string ResourceType
    }
    class CreateApplicationDto {
        +string ResourceType
        +string? ResourceName
        +string ResourceDesc
    }
    class CreateChannelDto {
        +string ResourceType
        +string? ResourceName
        +string ResourceDesc
    }
    class CreateDataRecordDto {
        +string ResourceType
        +string? ResourceName
        +string ContentType
        +string Content
        +DateTime? Expiration
    }
    class CreateSubscriptionDto {
        +string ResourceType
        +string? ResourceName
        +int EventType
        +string Endpoint
        +DateTime? Expiration
    }
    class ResourceResponseDto {
        +string ResourceType
        +string ResourceName
        +DateTime CreationDate
    }
    class NotificationDto {
        +string Event
        +string ResourcePath
        +DataRecordResponseDto DataRecord
    }
    class DtoResolver {
        +Resolve(envelope, json)
    }
    class DtoMapper {
        +ToResponse(domainObject)
    }
    DtoResolver --> CreateResourceEnvelope
    DtoResolver ..> CreateApplicationDto
    DtoResolver ..> CreateChannelDto
    DtoResolver ..> CreateDataRecordDto
    DtoResolver ..> CreateSubscriptionDto
    DtoMapper --> ResourceResponseDto
    NotificationDto --> ResourceResponseDto : embeds record projection
```

This diagram shows *conceptual* types, not mandatory inheritance. `CreateResourceEnvelope` serves only to read `res-type`; the resolver must validate both type and **parent path**. The specialized DTOs have different fields. `ResourceResponseDto` represents a **family** of response DTOs including every official field for each resource; it must not be implemented as an incomplete response. `NotificationDto` is [PROPOSAL], since the brief does not prescribe event envelope keys. See exact examples in `../18-contratos-dto-e-mapeamento.md`.
