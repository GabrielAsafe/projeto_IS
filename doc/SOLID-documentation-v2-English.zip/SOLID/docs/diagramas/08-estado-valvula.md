# Valve state diagram

**Proposed model**, not a completed implementation.

```mermaid
stateDiagram-v2
    [*] --> WaitingForEvent
    WaitingForEvent --> ON: humidity < threshold
    WaitingForEvent --> OFF: humidity >= threshold
    ON --> ON: humidity < threshold
    ON --> OFF: humidity >= threshold
    OFF --> ON: humidity < threshold
    OFF --> OFF: humidity >= threshold
    ON --> [*]: application stopped
    OFF --> [*]: application stopped
```

Proposed states and transitions. A notification with an invalid payload must be logged/flagged without causing a state transition based on a nonexistent measurement; the exact policy must be decided during implementation.
