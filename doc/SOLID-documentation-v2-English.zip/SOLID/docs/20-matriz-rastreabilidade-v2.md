# 20 — Requirements, diagrams, and tests traceability

| Requirements | Rationale / model | Main diagrams | Evidence to produce during implementation |
|---|---|---|---|
| SOL-F01..F04, SOL-F16 | 04, 05, 18 | 01, 02, 05, 11 | POST for each type; dispatch by `res-type`; official names |
| SOL-F05..F08, SOL-F14 | 05, 19 | 01, 10, 13 | GET/PUT/DELETE and duplicated/generated names |
| SOL-F09..F12 | 06 | 04, 06, 10 | Recursive discovery, `[]`, `/subs`, no Get all |
| SOL-F13, SOL-F15 | 07, 19 | 02, 09, 13 | ISO, expired-resource removal, no Valve polling |
| SOL-F17..F20 | 07, 18 | 05, 07, 12, 13 | Notification JSON, HTTP POST, MQTT channel topic |
| SOL-F21..F23 | 05, 14, 18 | 03, 11 | Complete responses and Swagger/OpenAPI, no SQL ID |
| SOL-F24..F30 | 08, 16 | 03, 07, 08 | Sensor 1/s 0..100, event-driven Valve, XML and XSD |

**Status:** this matrix describes *what to test*, not completed tests. To resolve unspecified behavior, consult `13-duvidas-e-decisoes.md`.
