# 14 — Swagger/OpenAPI contract: checklist

## Document explicitly

1. HTTP base `http://localhost:8765/api/solid` and deployment context.
2. All supported `POST`, `GET`, `PUT`, and `DELETE` operations from the CRUD table.
3. The optional `solid-discovery` **header** on GET requests and allowed values.
4. Difference between regular GET (single DTO) and discovery GET (`string[]`).
5. Mandatory `res-type` in bodies and JSON fields with literal hyphens.
6. Server-generated `dt-creation`; optional `dt-expiration` and ISO 8601 format.
7. `content` string with a `content-type` that may be JSON/XML/text.
8. **Immutability** of `data-record`/`subscription` (no PUT).
9. Subscription URI containing `/subs` in GET/DELETE and discovery responses.
10. Creation/update responses with complete representation and no internal IDs.
11. Consistent response codes and error examples.
12. Concrete examples of all four types and discovery, including `200 []`.

## Quality criterion

Use the cURL examples in `09-exemplos-curl.md` to verify that Swagger schemas and examples reflect actual behavior. A generated JSON OpenAPI specification does not necessarily provide a **Swagger UI**: the visual interface must also be configured if assessment requires it.
