# 22 — Glossary of terms and acronyms

| Term | Definition in the SOLID context |
|---|---|
| SOLID | **Service-Oriented Layer for Interoperable Data** (platform name, not the five OO SOLID principles) |
| `SOL-F01` | `SOL` = project; `F` = **Functional** (functional requirement); `01` = sequential number; IDs created by the team, not by the instructor |
| `Q-13` | Question no. 13 in `13-duvidas-e-decisoes.md`: retry, QoS, ordering, and delivery guarantees |
| API | Application Programming Interface |
| REST | Representational State Transfer |
| CRUD | Create, Read, Update, Delete |
| DTO | Data Transfer Object; structure for transferring data across the API boundary |
| `res-type` | Public JSON field identifying `application`, `channel`, `data-record`, or `subscription`; **not** an SQL identifier |
| HTTP | Hypertext Transfer Protocol |
| MQTT | Publish/subscribe protocol, historically MQ Telemetry Transport |
| QoS | Quality of Service, MQTT protocol delivery assurance levels |
| JSON | JavaScript Object Notation |
| XML | Extensible Markup Language |
| XSD | XML Schema Definition |
| SQLite | Embedded relational database engine required for persistence |
| PK / FK | Primary Key / Foreign Key; internal identifiers, not public URLs |
| ORM | Object-Relational Mapper (optional technology, not required) |
| `BackgroundService` | .NET base class for background services; implements `IHostedService` |
| `PeriodicTimer` | .NET timer proposed for periodically running the expiration process |
| Broker | MQTT intermediary between publishers and subscribers |
| TTL | Time To Live; in this project, `dt-expiration` and the removal policy |
| ADR | Architecture Decision Record; rationale and status of a decision |
| Modular monolith | One middleware process with separate internal responsibilities |
| OpenAPI | Formal description of the REST contract; Swagger can provide an exploration UI |

**Labels used:** `[REQUIREMENT]` = in the brief; `[PROPOSAL]` = reversible technical decision; `[QUESTION]` = ambiguity to clarify.
