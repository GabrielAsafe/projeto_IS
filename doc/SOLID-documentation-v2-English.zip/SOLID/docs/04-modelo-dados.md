# 04 — SQLite data model (v2)

**[PROPOSAL]** Four tables because there are four persistent resource types. SQL names are internal; public contracts use **exact** JSON property names. See `18-contratos-dto-e-mapeamento.md` and diagrams `01`/`02`.

| Table | Internal attributes | Exposed REST properties |
|---|---|---|
| `applications` | `id` PK, unique `resource_name`, `resource_desc`, `created_at` | `res-type`, `resource-name`, `resource-desc`, `dt-creation` |
| `channels` | `id` PK, `application_id` FK, `resource_name`, `resource_desc`, `created_at` | Same as `application` type |
| `data_records` | `id` PK, `channel_id` FK, `resource_name`, `content_type`, `content`, `created_at`, `expires_at` | `res-type`, `resource-name`, `content-type`, `content`, `dt-creation`, `dt-expiration` |
| `subscriptions` | `id` PK, `channel_id` FK, `resource_name`, `evt`, `endpoint`, `created_at`, `expires_at` | `res-type`, `resource-name`, `evt`, `endpoint`, `dt-creation`, `dt-expiration` |

## Relationships and keys

- `Application (1) → (0..*) Channel` allows the temporary state immediately after creating an application; the brief describes 1..N channels as the desired relationship (Q-18).
- `Channel (1) → (0..*) DataRecord` and `(0..*) Subscription`.
- `id`, `application_id`, `channel_id` are private. Public URLs and responses **never** expose PKs/FKs.
- `res-type` can be **derived from the table** when serializing a response, without an additional SQL column. This follows from using one table per type, **not** from having a single middleware instance.
- `subs` is a **virtual** path node, not an additional table.

## Uniqueness and validation in the v2 prototype

1. `applications.resource_name` is globally unique at the root.
2. `(application_id, resource_name)` is unique for channels.
3. `(channel_id, resource_name)` is unique separately for records and subscriptions, **and also across both types** through cross-table triggers [PROPOSAL — Q-03].
4. Reserve `subs` as a record `resource-name` [PROPOSAL — Q-21].
5. `subscription.evt IN (1,2)` **[REQUIREMENT]** §2.4.
6. Expiration and subscription indexes for lookups.
7. `ON DELETE CASCADE` **[PROPOSAL — Q-04]**; a SQL cascade by itself **does not** send notifications.

The middleware must generate a different name on **POST** when it is empty, duplicated, or reserved, before insertion. Triggers are only an integrity safeguard; an SQL error does not replace a proper JSON response.

## Dates and content

`created_at` is generated **by the server** and returned as ISO 8601 `dt-creation`. `expires_at` is nullable and represents optional `dt-expiration` for the two expiring types. [PROPOSAL] Normalize to UTC internally before filtering; lexicographical comparisons are incorrect when mixed offsets are used. `content` stores *text*, even for MIME types `application/json`/`application/xml`.

## State and files

`sql/schema.sql` and `sql/seed.sql`: reproducible prototype. `data/solid-modelo-exemplo.db`: demonstration with `app1` → `channel1` → `dr1` and `sub1`, **not** a database operated by a .NET API. Rules and exceptions in `19-politica-nomes-e-cascatas.md`.
