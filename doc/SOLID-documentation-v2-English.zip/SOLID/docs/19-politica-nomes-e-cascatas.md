# 19 — Naming, deletion, event, and expiration policies (v2)

**Note:** Policies marked [PROPOSAL] are **provisional** choices intended to keep the SQL prototype consistent. They are not instructor confirmations.

## 1. Uniqueness: what is known

**[REQUIREMENT]** `resource-name` is unique within its **parent**, not globally. The API identifies resources by names/paths; when a name is empty or duplicated, the middleware **generates a unique name** and returns it. A channel named `channel1` can exist in two separate applications.

**[V2 PROPOSAL — strict interpretation Q-03]** In the same channel, the sets of `data-records` and `subscriptions` names must not overlap. The schema implements `UNIQUE(channel_id, resource_name)` in each table **and cross-table triggers** to block collisions. Although `/subs` permits distinct public paths, this conservative rule follows the literal reading of "within the parent". If the instructor permits name reuse across types, remove the cross-table triggers.

**[V2 PROPOSAL — Q-21]** `data-record.resource-name` cannot be `subs` (case-insensitive) because the direct route `/.../{channel}/subs` is reserved as a virtual node. When that name is requested, the service should generate a valid alternative rather than return a duplicate-name error. This policy is not explicitly defined by the brief.

**[PROPOSAL]** Generate a name before persistence and, in case of a race/uniqueness violation, try another one; triggers are the last defense and do not replace contract-level handling.

## 2. Cascades — Q-04

V2 retains `ON DELETE CASCADE` on `channels`, `data_records`, and `subscriptions` to ensure referential integrity when a parent is deleted. **This is infrastructure, not complete public semantics**. Confirmation is needed about:

- whether DELETE of an application/channel is permitted when children exist;
- whether children removed by cascade trigger `evt=2` for each deleted data-record;
- which subscriptions are recipients before they too are removed.

## 3. Deletion event — Q-05

The general description says deleting a data-record triggers a notification. For direct DELETE, the architecture should capture a **snapshot of the record before removal**, COMMIT, and publish with `event=deletion` and the original path.

**Yet to be confirmed:** Should automatic TTL removal and indirect cascade deletion publish events? V2 keeps both as open decisions, **without claiming implemented functional coverage**. SQL FKs/integrity triggers cannot send HTTP/MQTT on their own.

## 4. Expiration — TTL

**[REQUIREMENT]** Only `data-record` and `subscription` have `dt-expiration`; absent/empty = no expiration. Given a valid date, the middleware removes the resource when the current time exceeds the deadline. **[PROPOSAL]** Store in uniform UTC ISO 8601 and use a `BackgroundService` with a periodic timer. The internal timer is not the measurement polling prohibited in the Valve.

Safe date comparisons require normalizing offsets/timezones rather than blindly comparing heterogeneous ISO 8601 strings. The SQL column is `TEXT`, but the service must interpret the value temporally and store a normalized representation (ideally UTC).

## 5. Consequences for tests

| Test | Expected under requirement / decision |
|---|---|
| Same names in different applications | allowed (e.g., `channel1` in `app1` and `app2`) |
| Duplicate name under same parent | middleware assigns another name on **creation** |
| Record and subscription with same name in same channel | prevented **[PROPOSAL Q-03]** |
| Create record named `subs` | generate alternative **[PROPOSAL Q-21]** |
| Delete record directly | emit deletion event `evt=2` to eligible subscriptions |
| Delete channel with records | integrity via cascade **[PROPOSAL Q-04]**; events to be decided |
| Expire subscription | resource removed; not a record event |
| Expire data-record | resource removed; notification policy **[QUESTION Q-05]** |
