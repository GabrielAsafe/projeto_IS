# 08 — Mandatory scenario: automatic irrigation

## Actors and applications

- **Moisture Sensor Application**: independent application; simulates a humidity measurement `0 ≤ h ≤ 100` each second, publishing each measurement as a data-record in a SOLID channel.
- **Water Valve Application**: independent application; configures threshold `T` (percentage units), registers a subscription of type `evt=1`, receives middleware notifications, and decides valve state.
- **SOLID Middleware**: the only intermediary for communication between the two simulations.

## Decision rule

`humidity < threshold` ⇒ **ON**; `humidity >= threshold` ⇒ **OFF**. A measurement equal to the threshold must turn off the valve. Values 0 and 100 are valid.

## Main flow

1. Create an application and measurement channel in the middleware.
2. Start the Water Valve Application, configure its threshold, and create a `creation` `subscription` on the channel.
3. Start the Moisture Sensor Application, generate one value per second, and create a `data-record` containing the measurement (with automatically generated or assigned unique names).
4. SOLID persists the record and sends an HTTP or MQTT notification.
5. The valve receives the notification, extracts `content` from the data-record (or retrieves the resource identified in the event), validates the measurement, and updates its ON/OFF state.
6. **All** received notifications are saved in an XML file validated against an XSD defined by the team.

## Important points

- The valve **must not** continually query the channel for new measurements or use busy-waiting, polling, or periodic scanning.
- The **sensor's** one-second timer is permitted and mandatory.
- It is permitted to retrieve the data-record contents via URI **when a notification is received**. This is an event-triggered GET, not polling.
- Should invalid notifications be saved in XML? The brief says **all received** and states that items failing XSD are invalid; define whether they are stored separately or rejected with a log (Q-09).

## XML and XSD

The brief **does not supply** an XSD; the team must create one. Proposed root `<notifications>` with repeated `<notification>`, `<event>`, `<resourcePath>`, `<receivedAt>`, `<humidity>` elements, but the structure and handling of invalid entries must be agreed before implementation.

## Particularly important tests

Boundary values 0%, 100%, `h=T`, below/above; publication frequency; temporary destination failure; invalid payload; valid XML/XSD; evidence that no polling occurs.
