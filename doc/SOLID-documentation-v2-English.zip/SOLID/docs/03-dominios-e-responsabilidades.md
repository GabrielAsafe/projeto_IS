# 03 — Domains and responsibility boundaries

The following **logical modules** are a technical proposal; they do not imply independent microservices.

| Module | Responsibility | Owned data |
|---|---|---|
| Resource Registry | CRUD for `application`, `channel`, `data-record`, `subscription`; names and hierarchy | Four resources |
| Discovery | Resolve scope, traverse hierarchy, and return paths by type | Read-only; no entity of its own |
| Subscription & Notifications | Interpret `evt`, manage endpoints, and send HTTP/MQTT notifications | Subscription; optional internal delivery state |
| Expiration | Identify and remove expired `data-record`/`subscription` resources | Expiration dates and possible internal logs |
| Persistence | SQLite, indexes, integrity, transactions | Four tables, FKs |
| REST Interface | Resolve URI, validate DTO, HTTP codes, Swagger/OpenAPI contract | No domain data |
| Moisture Sensor Simulator | Produce a 0–100% sample each second and publish it through REST | Transient sensor state |
| Water Valve Simulator | Consume notifications, retrieve a measurement if needed, apply threshold, save XML, and validate XSD | Threshold, ON/OFF state, XML history |

## Allowed dependencies (proposed)

- HTTP layer → application services → repositories/domain.
- Data-record CRUD → event component → HTTP/MQTT transport (without coupling to the simulated device).
- Expiration timer/service → repositories → deletion events **only if confirmed** that expiration must trigger notifications.
- Sensor and valve → public SOLID API; no direct access to the middleware database.

## Invariants

1. An `Application` may own multiple `Channel` instances.
2. A `Channel` may own multiple `DataRecord` and multiple `Subscription` instances.
3. A `Subscription` has `evt=1` or `evt=2` per §2.4 (despite the earlier mention of both).
4. `subs` is a REST routing detail, not a persisted table/resource.
5. Public names need only be unique within the parent's scope; internal identifiers never leave the infrastructure.
