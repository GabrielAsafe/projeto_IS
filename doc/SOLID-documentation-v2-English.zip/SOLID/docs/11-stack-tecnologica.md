# 11 — Technology stack: criteria and constraints (v2)

**[REQUIREMENT]** Implement in .NET 10 with SQLite persistence and REST JSON API, port 8765, Swagger/OpenAPI, HTTP and MQTT notifications. **[REQUIREMENT]** §6 restricts technologies/frameworks/methodologies to those covered in practical classes. All libraries below are **candidates**, not confirmed choices.

| Layer | Candidate A | Candidate B | Criterion |
|---|---|---|---|
| API | ASP.NET Core Controllers | ASP.NET Core Minimal APIs | Clarity of hierarchical routes, OpenAPI, class practices |
| Persistence | EF Core SQLite | Microsoft.Data.Sqlite / ADO.NET | Mapping, control over triggers, class coverage |
| MQTT | MQTTnet library **if authorized** | MQTT client taught in class | Publisher, broker URI, topics, QoS, practical broker |
| Internal TTL service | `BackgroundService` + `PeriodicTimer` | Direct implementation of `IHostedService` | Simplicity, lifecycle and tests, class coverage |
| Sensor | .NET 10 Console/Worker | .NET 10 UI | Independent, publish each second |
| Valve | HTTP POST endpoint | Subscribed MQTT client | Push notification without polling; XML + XSD |
| OpenAPI | ASP.NET OpenAPI APIs | Additional Swagger UI | Complete schemas + UI if required |

**Conceptual clarification:** `BackgroundService` **is an implementation of** `IHostedService` (they are not semantically equivalent), and `PeriodicTimer` controls the worker's execution frequency. `MQTTnet` is an MQTT integration library; it does **not necessarily replace** a configured/running broker. Instructor confirmation is needed.

## Logical solution structure (optional)

- `Solid.Api`: routes, JSON/DTOs, status codes, and OpenAPI.
- `Solid.Domain`: four entities and invariants.
- `Solid.Application`: creation/update/deletion, discovery, notifications (coordination).
- `Solid.Infrastructure`: SQLite, HTTP/MQTT, expiration worker.
- `Solid.SensorSimulator` and `Solid.ValveSimulator`: **independent applications**.
- `Solid.Tests`: contract and flow tests.

Organizing into several C# projects can be simplified for the course: the rule is **logical separation**, not multiplying assemblies.

## Recommended technical spikes

1. Resolve `res-type` in the same channel POST and document it in OpenAPI.
2. Verify `/subs` routes and `solid-discovery` against official examples.
3. Confirm SQLite FKs, name triggers, transactions, and expiration model.
4. Experiment with HTTP POST and MQTT (broker/topic and Q-08).
5. Verify XML/XSD and event → optional GET → Valve decision flow.

Official runtime references to consult **after** confirming authorized technologies:
- https://learn.microsoft.com/en-us/aspnet/core/fundamentals/host/hosted-services?view=aspnetcore-10.0
- https://learn.microsoft.com/en-us/ef/core/providers/sqlite/
- https://learn.microsoft.com/en-us/aspnet/core/fundamentals/openapi/aspnetcore-openapi?view=aspnetcore-10.0
