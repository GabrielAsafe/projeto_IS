# 02 — Traceable functional requirements

Identifiers created for this documentation, not assigned by the instructor. Source: assignment brief, Sections 2–4.

| ID | Requirement | Source |
|---|---|---|
| SOL-F01 | Register an `application` at the root level | §2 / §2.1 |
| SOL-F02 | Create a `channel` within an `application` | §2 / §2.1 |
| SOL-F03 | Create a `data-record` in a `channel` | §2 / §2.1 |
| SOL-F04 | Create a `subscription` in a `channel` | §2 / §2.1 |
| SOL-F05 | Retrieve a resource using its `resource-name` and path | §2.1 |
| SOL-F06 | Update `application` and `channel` | §2.1 |
| SOL-F07 | Delete resources using the target path | §2.1 |
| SOL-F08 | Reject updates to `data-record` and `subscription`; recreate them to make changes | §2.1 |
| SOL-F09 | Discover resources recursively using `GET` + `solid-discovery` | §2.2–2.3 |
| SOL-F10 | Include `/subs/` in every discovered subscription path | §2.1–2.2 |
| SOL-F11 | Return `200` and `[]` when discovery is logically impossible | §2.3 |
| SOL-F12 | Do not expose a generic listing endpoint | §2.3 |
| SOL-F13 | Automatically assign `dt-creation` in ISO format | §2.4 |
| SOL-F14 | Generate `resource-name` if omitted or duplicated within the same scope | §2.4 |
| SOL-F15 | Automatically expire/remove data-records and subscriptions with `dt-expiration` | §2.4 |
| SOL-F16 | Accept only valid `res-type` values in the body and preserve official property names | §2 / §2.4 |
| SOL-F17 | Publish a data-record creation event to matching subscribers | §2 |
| SOL-F18 | Publish a data-record deletion event to matching subscribers | §2 |
| SOL-F19 | Send notifications via HTTP POST callback or MQTT broker | §2.1 / §2.4 |
| SOL-F20 | Include the event, affected resource, and complete path in the notification | §2.1 |
| SOL-F21 | Return the complete resource after creation/update, including any generated name | §2.1 |
| SOL-F22 | Persist resources and data in SQLite without exposing internal IDs | §2.1 / §2.4 |
| SOL-F23 | Expose complete and accurate Swagger/OpenAPI documentation | §2.4 |
| SOL-F24 | Simulate humidity between 0 and 100 every second | §4 |
| SOL-F25 | Publish each sample as a data-record in the middleware | §4 |
| SOL-F26 | Allow configuration of the valve humidity threshold | §4 |
| SOL-F27 | Subscribe to creation events and turn the valve on/off according to the threshold | §4 |
| SOL-F28 | Save all notifications received by the valve to XML | §4 |
| SOL-F29 | Define an XSD for the team's XML and validate against it | §4 |
| SOL-F30 | Simulation applications communicate exclusively through the middleware | §4 |

## Cross-cutting acceptance rules

- For all four resource categories, creation and discovery use the parent's URI; retrieval and deletion use the target's URI.
- Only `application` and `channel` can be updated.
- Discovery traverses descendants of the specified scope (without `Get all`).
- The subscription endpoint is stored; the MQTT topic is derived from the channel path at runtime.
- No response may expose SQLite primary keys.

## Verification strategy

Map these IDs to tests in `10-testes-casos.md`; concrete examples are in `09-exemplos-curl.md`. Section `13-duvidas-e-decisoes.md` identifies requirements with contradictory details.
