# 06 — Discovery and addressing

## Mandatory rules

- The `solid-discovery` header contains one of: `application`, `channel`, `data-record`, `subscription`.
- A normal `GET` (without the header) returns the **target resource**.
- A `GET` with the header returns a **JSON array of API-relative absolute paths** matching the requested type *within the scope* of the target URI.
- The scope may be `/api/solid`, an application, a channel, or another resource.
- Recursively search existing descendants; never provide a generic `Get all` route.
- If the target cannot contain the requested type, return `200 OK` with `[]`.
- Every discovered subscription has the path `/api/solid/{app}/{channel}/subs/{name}`.
- Subscriptions must not be treated as data-records when routing `/subs`.

## Scope matrix (typical result)

| Target | discovery=application | discovery=channel | discovery=data-record | discovery=subscription |
|---|---|---|---|---|
| Root `/api/solid` | descendant apps | descendant channels | descendant records | descendant subs |
| `/api/solid/{app}` | `[]` | channels | records | subs |
| `/api/solid/{app}/{ch}` | `[]` | `[]` | records | subs |
| `data-record` path | `[]` | `[]` | `[]` | `[]` |
| `subscription` path | `[]` | `[]` | `[]` | `[]` |

**[QUESTION]** The matrix assumes discovery considers *descendants*, excluding the target resource itself; confirm this when testing the official examples.

## Conceptual algorithm

1. Resolve the target path; validate the tree and handling of `subs`.
2. If `solid-discovery` is present, validate its value.
3. Discover descendants of the requested type in the target subtree (one scoped database query or a controlled traversal).
4. Project each result into a public path using **names**, not IDs.
5. Return a JSON list of strings; optionally sort it to make tests deterministic.
