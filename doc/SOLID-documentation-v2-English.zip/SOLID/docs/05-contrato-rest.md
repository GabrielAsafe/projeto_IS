# 05 — REST API and operations (v2)

**[REQUIREMENT]** Base `http://<host>:8765/api/solid`. JSON in requests/responses. The table identifies **proposed REST routes consistent** with the assignment examples; PUT operations are not illustrated and must be validated.

## CRUD routes

| Type | Create | Retrieve | Update | Delete |
|---|---|---|---|---|
| `application` | `POST /api/solid` | `GET /api/solid/{app}` | `PUT /api/solid/{app}` | `DELETE /api/solid/{app}` |
| `channel` | `POST /api/solid/{app}` | `GET /api/solid/{app}/{channel}` | `PUT /api/solid/{app}/{channel}` | `DELETE /api/solid/{app}/{channel}` |
| `data-record` | `POST /api/solid/{app}/{channel}` | `GET /api/solid/{app}/{channel}/{record}` | **not supported** | `DELETE /api/solid/{app}/{channel}/{record}` |
| `subscription` | `POST /api/solid/{app}/{channel}` | `GET /api/solid/{app}/{channel}/subs/{subscription}` | **not supported** | `DELETE /api/solid/{app}/{channel}/subs/{subscription}` |

The two `POST` operations for the same channel use the required `res-type` field in JSON to distinguish creation of a `data-record` from creation of a `subscription`. Do not add `POST .../subs` without confirmation: the brief explicitly says creation identifies the **parent channel**.

## Examples of public payloads (exact fields)

### Create application

```http
POST /api/solid
Content-Type: application/json
```
```json
{"res-type":"application","resource-name":"app1","resource-desc":"IoT application"}
```

### Create channel

```http
POST /api/solid/app1
Content-Type: application/json
```
```json
{"res-type":"channel","resource-name":"channel1","resource-desc":"Measurements"}
```

### Create data-record

```http
POST /api/solid/app1/channel1
Content-Type: application/json
```
```json
{"res-type":"data-record","resource-name":"dr1","content-type":"application/json","content":"{\"humidity\":45}","dt-expiration":null}
```

`content` is a string even if `content-type` indicates JSON. `dt-creation` is automatically added by the server to the response. The null value illustrates the absence of an expiration date, subject to confirmation of the representation format.

### Create HTTP subscription

```http
POST /api/solid/app1/channel1
Content-Type: application/json
```
```json
{"res-type":"subscription","resource-name":"sub1","evt":1,"endpoint":"http://localhost:9090/notifications","dt-expiration":null}
```

### Resource discovery

```http
GET /api/solid/app1
solid-discovery: data-record
```
```json
["/api/solid/app1/channel1/dr1"]
```

```http
GET /api/solid/app1
solid-discovery: subscription
```
```json
["/api/solid/app1/channel1/subs/sub1"]
```

## Suggested HTTP codes (not completely specified)

- Creation: `201 Created` + body with the complete representation and actually assigned name.
- Retrieval/update/discovery: `200 OK` + JSON (impossible discovery returns `[]`).
- Deletion: `204 No Content` (unless the instructor requires a representation; the "complete representation" requirement explicitly covers creation/update).
- Missing name/parent: `404 Not Found`; invalid payload: `400 Bad Request`.
- Attempt to update immutable resources: `405 Method Not Allowed` or `400`, a decision to validate and document in OpenAPI.

The REST API never returns internal SQLite IDs and does not implement a `GET /api/solid` that returns all resources without the discovery header.

## v2 architectural interpretation

The same `POST /api/solid/{app}/{channel}` accepts `data-record` and `subscription`, distinguished by a **mandatory** `res-type`. This is not a single DTO with every property; in the proposal, the REST layer selects a specialized DTO by type after reading an envelope, validates the parent, and maps it to the domain. JSON and DTO are not conceptually the same entity. `dt-creation` is generated on the server; not storing a `res-type` column is one possible implementation. Detailed contracts in `18-contratos-dto-e-mapeamento.md`.

For expiration/cascade deletions, see `19-politica-nomes-e-cascatas.md`; for notes about the instructor's intended interpretation, see `13-duvidas-e-decisoes.md`.
