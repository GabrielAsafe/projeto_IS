# 07 — HTTP/MQTT notifications, contract, and expiration (v2)

## Required by the assignment brief

- Creating a `data-record` produces a **creation** event; deleting it produces a **deletion** event.
- `subscription.evt = 1` means creation and `2` means deletion (§2.4). The earlier mention of "both" remains contradictory (Q-01).
- Notifications must include the **event type, affected resource, and complete path**.
- HTTP: `endpoint` is a URL that receives `POST`.
- MQTT: `endpoint` stores the **broker** address. The **topic** is calculated *at runtime* from the channel path, e.g., `api/solid/app1/channel1`.
- `data-record` and `subscription` may have `dt-expiration`; an expired resource must be removed automatically.

## Proposed event contract (the same content over HTTP and MQTT)

```json
{
  "event": "creation",
  "resource-path": "/api/solid/app1/channel1/dr1",
  "data-record": {
    "res-type": "data-record",
    "resource-name": "dr1",
    "content-type": "application/json",
    "content": "{\"humidity\":45}",
    "dt-creation": "2026-10-27T09:00:00Z",
    "dt-expiration": null
  }
}
```

The **notification envelope keys** are a team proposal, unlike the **properties inside the resource**, whose names are mandated.

## Routing and separation of responsibilities

1. REST validates DTO, `res-type`, and parent; ResourceApplicationService handles persistence.
2. Save/commit the record in SQLite.
3. Notify `NotificationCoordinator` **after** persistence; identify channel subscriptions filtered by `evt`.
4. The HTTP adapter sends JSON via `POST`; the MQTT adapter publishes JSON on the calculated topic to the broker in `endpoint`.
5. An external receiver (e.g., Valve) consumes *push* notifications (no polling); it may retrieve the record by GET **after** receiving a notification, if necessary.

**Note:** Sending after commit without an outbox means a process failure between commit and send can lose events. The exact delivery guarantee, retry, and QoS are open questions (Q-13). We do not invent confirmed-delivery semantics.

## How to distinguish HTTP from MQTT? (Q-08)

Without a public `protocol` field, we can only propose a convention based on `endpoint` or another internal dispatch rule. For example, `http://`/`https://` → HTTP and a valid broker URI `mqtt://...` → MQTT **[PROPOSAL SUBJECT TO APPROVAL]**. Do not store the topic in the MQTT `endpoint` property. Confirm whether the broker/client taught in class supports the proposed URI schemes.

## Expiration worker

[PROPOSAL] An internal `BackgroundService` + `PeriodicTimer` queries SQLite, removes records/subscriptions whose expiration precedes the current time, and follows a deletion/notification policy. This is **not** the polling forbidden in the Valve, because the Valve only detects measurements through notifications. `BackgroundService` implements `IHostedService`; these are not competing technologies at the same level.

## Deletions: do not assume a policy that does not exist

- Explicit `DELETE` of a data-record: emit deletion (with a pre-deletion snapshot to preserve its content).
- Data-record expiration: whether it must also emit deletion is **Q-05**.
- Cascade deletion of application/channel: database behavior [PROPOSAL]; possible messages for child records **Q-04/Q-05**.
- Deleting a subscription does not generate a data-record event.

References: `18-contratos-dto-e-mapeamento.md`, `19-politica-nomes-e-cascatas.md`, and diagrams `05`, `09`, `12`, `13`.
