# 12 — Technical plan and final submission

## Assessment criteria (structured transcription of §5)

The assignment table shows: **Middleware 60%** (4 resource types with CRUD/Discovery, 15% each); **removal by `dt-expiration` 5%**; **Testing application 20%**; **Report 15%**. The table is visually ambiguous about how the expiration item is nested; together, the listed items total 100% when the 5% is treated separately. Confirm this interpretation with the instructor.

## Suggested stages (no sprints are defined in the brief)

1. **Modeling/contract:** hierarchy, exact public names, DTOs, paths, ambiguities, SQLite, basic Swagger.
2. **CRUD:** application and channel, then data-record and subscription; name/ID tests.
3. **Discovery and expiration:** header, recursive paths, cleanup service, error cases.
4. **Notifications:** creation/deletion, HTTP POST callbacks, MQTT publication, tested transport.
5. **Mandatory scenario:** independent sensor and valve; XML, XSD, ON/OFF logic, and E2E without polling.
6. **Hardening:** mandatory data, SQL recreation scripts, Swagger documentation, comprehensive cURL commands, report, and individual discussion.

## Submission (§7)

Submit on the course page **a link to one external ZIP or 7z archive** containing:

```text
identification.txt
Project/    # full source code, dependencies, and required resources
Report/     # report following the official template, PDF or DOCX
Other/      # XML/XSD and relevant resources not included above
Data/       # SQLite .db file + .sql scripts to recreate and populate it
```

The report has a mandatory appendix specifying **which features each team member implemented**. The template and exact due date are on the official course page/calendar and **were not supplied** with this material.

## Individual presentation/discussion checklist

- Explain endpoints and the difference between normal GET and discovery.
- Show why `/subs` is virtual and internal IDs do not appear.
- Demonstrate HTTP/MQTT events and topic resolution.
- Demonstrate that the valve reacts only to events, without polling.
- Validate XML against XSD.
- Open the DB containing the four mandatory resources, and demonstrate expiration and SQL reconstruction.
- Run all cURL examples and navigate Swagger.
