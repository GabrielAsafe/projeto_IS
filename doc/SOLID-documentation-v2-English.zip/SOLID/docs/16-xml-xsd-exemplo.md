# 16 — Notification log XML/XSD (example)

These are **schema examples**, not an official XSD from the assignment brief or files produced by a working application:

- `../exemplos/valve-notifications.xsd`
- `../exemplos/valve-notifications-example.xml`

The brief requires **all notifications received by the Water Valve Application** to be saved in XML and the XML to be validated against an XSD created by the team. The proposed model records event, public URI, timestamp, humidity, and optional text payload. It restricts values to 0..100 and supports creation/deletion.

**Intentional limitation:** Notifications without valid humidity are not accepted by this schema, so the team must choose how to retain evidence of invalid notifications without violating the rule to persist all received notifications. The actual structure must be aligned with the middleware's effective payload, which is not fixed by the brief.
