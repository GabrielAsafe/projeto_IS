# 13 — Ambiguities, decisions, and assumptions (v2)

**Initial status:** all proposals must be validated with the instructor or against official criteria. Do not change public names to "correct" the brief without validation.

| ID | Question | Brief / reason | Provisional approach |
|---|---|---|---|
| Q-01 | Can `evt` represent "both"? | §2.1 says creation/deletion/both; §2.4 allows only 1 or 2 | Implement only 1 and 2; request clarification |
| Q-02 | Is the subscription date field `dtcreation`? | One table in §2 writes `dtcreation`; §2.4 mandates `dt-creation` for all | Consistently use `dt-creation` |
| Q-03 | Must names be unique across both kinds of channel children? | Parent resource scope; distinct URIs thanks to `/subs` | **V2:** cross-table triggers enforce different record/sub names in the same channel [PROPOSAL]; ask |
| Q-04 | Should deleting channel/application delete descendants? | Hierarchy does not fix cascade behavior | **V2:** SQL with `ON DELETE CASCADE` [PROPOSAL]; event policy pending |
| Q-05 | Does automatic expiration deletion trigger a notification? | Data-record deletion events; expiration removes resource | Escalate decision; avoid undocumented silent behavior |
| Q-06 | Is empty `dt-expiration` represented by `null` or `""`? | §2.4 allows omitted/empty | Accept `null`/absent, convert according to agreed contract |
| Q-07 | What is the exact notification payload format? | Only 3 mandatory components described | Define JSON schema, document it, and integrate both simulators |
| Q-08 | How to distinguish an HTTP vs MQTT endpoint? | HTTP URL versus MQTT broker endpoint, without a protocol field | Propose URI scheme; validate with instructor |
| Q-09 | What to do with invalid notifications in XML? | Persist all received; nonconforming ones are invalid under the schema | Save raw separately or handle errors; validate interpretation |
| Q-10 | Does discovery include the target resource itself? | Says "within scope" and recursive | Interpret as descendants without self-inclusion |
| Q-11 | Can a resource name be updated by PUT? | Apps/channels can be updated; identified by name | Prioritize updating descriptions; ask about renaming |
| Q-12 | What are the DELETE and error status codes? | Requires appropriate status without listing all codes | Adopt 201/200/204/400/404/405, document |
| Q-13 | Retries, QoS, ordering, and delivery guarantees? | Unspecified | Simple version is sufficient; measure failures |
| Q-14 | Which library technologies are authorized? | §6 restricts technologies to practical classes | Confirm EF Core, MQTTnet, Swagger UI, tests, IDE |
| Q-15 | Does MQTT notification use an external or embedded broker? | `endpoint` must store broker | Prefer broker taught in class, no mandated vendor |
| Q-16 | Is there a GET endpoint for the root without a header? | Generic `Get all` expressly forbidden | Do not return a collection; make error/documentation explicit |
| Q-17 | Must the valve demo use both transports? | Middleware supports HTTP + MQTT; scenario requires notifications | Implement both in middleware; demonstrate at least one in scenario; confirm |
| Q-18 | Minimum channels per application | "One or more", but deleting the last channel could violate cardinality | Enforce on creation? Confirm with instructor; DB only enforces FK |
| Q-19 | HTTP "application/json" while JSON is text inside `content` | Data-record `content-type` is the content MIME; REST body is JSON | Store text and serialize a JSON string, even for XML/JSON |
| Q-20 | Valid presentation of ISO date/time | Example without timezone; §2.4 requires ISO 8601 | Use UTC ISO 8601 and document representation/display |
| Q-21 | May a data-record be named `subs`? | Direct record route collides with the virtual subscription node | **V2:** forbid `subs` as a record name via CHECK and generate alternative [PROPOSAL] |

## v2 revision log

- **Q-03 and Q-21:** there is now a provisional rule **implemented in the SQL prototype**, not approved by the instructor. See `19-politica-nomes-e-cascatas.md`.
- **Q-04/Q-05:** referential integrity and notifications are separate concerns; a cascade does not imply a callback.
- **Q-07/Q-08/Q-13:** JSON contract proposed; broker URI and delivery guarantees pending.
- **Q-18:** domain diagrams show 0..* channels during initial setup.

## Recommended resolution order

High priority: Q-01, Q-02, Q-03, Q-05, Q-08, and Q-14. Medium priority: Q-04, Q-06, Q-07, Q-10, Q-11. The others can be clarified during spikes and testing.
