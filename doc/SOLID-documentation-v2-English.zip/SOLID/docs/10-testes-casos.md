# 10 — Initial test matrix

**[PROPOSAL]** Test cases derived from the assignment brief. The course does not require BDD/Gherkin/Katalon for this project; use testing technologies actually taught.

| ID | Scenario | Essential verification | Requirements |
|---|---|---|---|
| T-01 | Create application | 201, explicit name, dt-creation, DTO without PK | F01, F13, F22 |
| T-02 | Omitted name | generates and returns a name | F14, F21 |
| T-03 | Duplicate name under the same parent | generates and returns a unique name | F14 |
| T-04 | Create channel without existing application | fails with an appropriate error | F02 |
| T-05 | Update application/channel | updated representation | F06, F21 |
| T-06 | Update data-record/subscription | rejected; resource unchanged | F08 |
| T-07 | Read record by URL | only public fields | F05, F22 |
| T-08 | Read subscription through `/subs/` | success; alternative URL is not a subscription | F05, F10 |
| T-09 | Recursive discovery from root | correct paths by type | F09 |
| T-10 | Subscription discovery | includes `/subs/` | F10 |
| T-11 | Impossible discovery on record | 200 and `[]` | F11 |
| T-12 | GET without header | returns one resource, not an array of descendants | F12 |
| T-13 | Creating a record triggers creation callback | `evt=1`, full URI and record | F17, F19, F20 |
| T-14 | Deleting a record triggers deletion callback | `evt=2`, full URI and record | F18, F19, F20 |
| T-15 | Unsubscribed event | do not send to subscription for another event | F17, F18 |
| T-16 | MQTT | publishes to broker endpoint and channel topic | F19 |
| T-17 | Record expiration | automatically removed after deadline | F15 |
| T-18 | Subscription expiration | no longer receives notifications after deadline | F15 |
| T-19 | No expiration | not automatically removed | F15 |
| T-20 | Sensor emits 1 reading/second | values 0..100, data-records | F24, F25 |
| T-21 | Measurement below threshold | valve ON in response to notification | F26, F27 |
| T-22 | Measurement equals threshold | valve OFF | F26, F27 |
| T-23 | Measurement above threshold | valve OFF | F26, F27 |
| T-24 | Valid XML | all notifications saved and XSD validated | F28, F29 |
| T-25 | Flow without polling | inspect logs/code paths: only events trigger decisions | F30 |
| T-26 | Sample DB | `app1`, `channel1`, `dr1`, `sub1` present | §2.4 |
| T-27 | Swagger | all resources, headers, statuses, schemas | F23 |

## Recommended testing strategy

1. **Unit:** names, rules, expiration, ON/OFF calculation, and DTO serialization.
2. **Integration (real SQLite):** FKs, transactions, creation/discovery/deletion, timestamps.
3. **HTTP contract:** cURL/Postman and OpenAPI documentation; distinguish requests with and without the header.
4. **E2E:** middleware + sensor + valve + transport + XML/XSD.

## Suggested definition of done

Automated tests pass, Swagger is consistent, cURL examples are executed, SQLite data are correct, and the report is prepared with real evidence (logs or screenshots). The brief does not define a formal Definition of Done.

## V2 — Additional checks to automate

- JSON with invalid `res-type` or one incompatible with the parent ⇒ no resource is created.
- POST to channel with both types ⇒ correct specialized DTO; generated `resource-name` when duplicated.
- Subscription/record with the same name in the same channel ⇒ document **[PROPOSAL Q-03]** behavior.
- Record named `subs` ⇒ alternative name **[PROPOSAL Q-21]**.
- Delete record ⇒ deletion payload preserves data/URI even after deletion.
- Data-record TTL ⇒ measure notification behavior after Q-05 decision.
- HTTP and MQTT ⇒ comparable payload and correct broker/topic, with no polling.
- Review `13-duvidas-e-decisoes.md` with the instructor before declaring the contract final.

The script `../tests/test_sqlite_model.py` only validates the **schema and seed**, not REST routes or notification delivery.
