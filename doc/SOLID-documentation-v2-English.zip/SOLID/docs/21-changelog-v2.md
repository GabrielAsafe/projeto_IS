# 21 — v2 history (compared with v1)

1. **Diagram separation:** `01` now represents the **domain only**; `10` represents **services/dependencies**; `11` DTOs/discriminator.
2. **Architecture clarified:** `03` represents a modular monolith, external Sensor/Valve, and notifications after persistence.
3. **Updated flows:** `05` creation+DTO; `07` irrigation; `09` expiration; new `12` HTTP/MQTT notification and `13` deletion.
4. **DTO contract added:** `18-contratos-dto-e-mapeamento.md` distinguishes `res-type`, JSON envelope, DTOs, and SQL entity.
5. **Naming/deletion policy:** `19-politica-nomes-e-cascatas.md` explains cross-type uniqueness [PROPOSAL], reservation of `subs`, and unresolved cascade/events.
6. **SQL and demonstration DB:** triggers for record/sub name collisions and reserved `subs`, sample data rebuilt and tested locally (no real API).
7. **Rationale:** `17-justificacao-modelacao.md` explains choices and what is required/proposed/questioned.
8. **Traceability:** `20-matriz-rastreabilidade-v2.md` maps features to diagrams and future evidence.
9. **Acronyms and statuses:** `22-glossario.md` distinguishes the SOLID project, SOL-F IDs, and technical abbreviations.
10. **Compatibility:** v1 documents and examples were preserved and updated where needed; the source `00-enunciado-original.txt` was unchanged in the Portuguese version.

## What v2 **is not**

It is not a working .NET 10 implementation, certification of compatibility with the libraries taught in class, or an instructor-approved decision on ambiguities in the brief. The package remains documentation/modeling + SQLite prototype.
