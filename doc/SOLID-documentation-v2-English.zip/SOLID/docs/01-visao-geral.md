# 01 — Overview and scope

**Project:** SOLID — Service-Oriented Layer for Interoperable Data  
**Course:** Systems Integration, 2026/2027  
**Source:** Sections 1–7 of the supplied assignment brief.  
**Objective:** Interoperable middleware enabling publication, retrieval, and discovery of hierarchical resources, as well as event-based notifications.

## Two applications distinct from the middleware

1. **SOLID Middleware:** REST API, SQLite persistence, resource hierarchy and discovery, automatic expiration, HTTP/MQTT notifications.
2. **Mandatory scenario:** Independent simulations of the `Moisture Sensor Application` (humidity measurement every second) and `Water Valve Application` (response to notifications and XML/XSD logging).

## Explicit constraints

- **.NET 10** for implementation; only technologies, frameworks, and methodologies taught in practical classes.
- REST API base `http://<host>:8765/api/solid` (mandatory `/api/solid` prefix).
- Persistence in **SQLite**; required demonstration resources `app1/channel1/dr1` and `app1/channel1/subs/sub1`.
- REST inputs/outputs in JSON; `data-record.content` is a string whose content may be XML, JSON, or text depending on `content-type`.
- Swagger/OpenAPI is mandatory.
- Hierarchy limited to application → channel → (data-record | subscription), with `/subs` as a virtual node for addressing subscriptions.
- There is **no** generic `Get all` operation; enumeration is exclusively through `solid-discovery`.
- Simulations communicate **exclusively through the middleware**; the valve receives notifications and never detects new measurements by polling.

## Interpretation notes

Sections labeled **[REQUIREMENT]** paraphrase obligations from the assignment brief; **[PROPOSAL]** identifies design/architecture choices; **[QUESTION]** identifies ambiguities requiring validation. See `13-duvidas-e-decisoes.md`.

## Outside the mandatory scope (do not assume)

Authentication, a web dashboard, cloud hosting, a specific MQTT broker technology, an external IoT API, retries, structured logging, and containers are not prescribed by the brief. They may be added subject to the restriction on technologies taught in class.
