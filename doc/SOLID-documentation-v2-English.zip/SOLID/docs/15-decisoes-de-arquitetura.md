# 15 — Architecture Decision Records (ADRs) — v2

ADRs **do not** replace the requirements of the brief or instructor validation.

## ADR-001 — Middleware as a modular monolith
- **Status:** proposed.
- **Decision:** one .NET 10 API process, with API, Application, Domain, and Infrastructure modules/layers.
- **Rationale:** a single contract, small hierarchy, and single SQLite database. The two simulators are independent processes.
- **Tradeoff:** simplicity and local operations versus discipline in separating responsibilities.

## ADR-002 — Public DTO versus SQL entity
- **Status:** proposed (separation is highly recommended).
- **Decision:** mandatory `res-type` envelope, type-specific DTO; serialize responses without internal IDs.
- **Rationale:** generic POST to parent, mandatory hyphenated JSON property names, private PKs/FKs.
- **Tradeoff:** explicit mapping increases code but ensures interoperability.

## ADR-003 — Common HTTP/MQTT notification contract
- **Status:** proposed; Q-07 and Q-08 pending.
- **Decision:** JSON with `event`, `resource-path`, and `data-record` for both transports; MQTT endpoint = broker, derived topic.
- **Rationale:** reuse in Valve; meet three essential data requirements from brief.
- **Tradeoff:** broker URI convention and retry handling are yet to be agreed.

## ADR-004 — Expiration as internal work
- **Status:** proposed; Q-05 pending for events.
- **Decision:** `BackgroundService + PeriodicTimer`, normalized timestamps, TTL removal.
- **Rationale:** housekeeping independent of requests; does not imply that the Valve polls the sensor.
- **Tradeoff:** cleanup frequency and notification implications.

## ADR-005 — Unique names by parent, including children of different types
- **Status:** proposed; Q-03 and Q-21 pending.
- **Decision:** keep cross-table triggers and reserve `subs` to prevent naming/routing ambiguities.
- **Rationale:** strict interpretation of uniqueness and virtual path.
- **Tradeoff:** may need relaxing if reuse across types is permitted.

## ADR-006 — Referential cascades separate from event publication
- **Status:** proposed; Q-04 and Q-05 pending.
- **Decision:** SQLite referential integrity via cascade; explicitly capture snapshots and publish after commit if the policy requires events for descendants.
- **Rationale:** SQL triggers do not send HTTP/MQTT, and a resource needs to exist as a snapshot in a deletion notification.
- **Tradeoff:** the project needs a clear policy for cascades and delivery ordering.
