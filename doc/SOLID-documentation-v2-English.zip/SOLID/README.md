# SOLID — Documentation and modeling **v2**

**Systems Integration, 2026/2027** — **SOLID: Service-Oriented Layer for Interoperable Data** project. This folder is a **complete evolution of v1** (without replacing the assignment brief). These are **modeling** artifacts, not operational .NET middleware.

## v2 deliverables

- **13 Mermaid diagrams**, each provided as a `.md` (with description) and an editable `.mmd` file.
- Separate diagrams for the **domain (`01`)**, **services (`10`)**, **DTOs (`11`)**, and new **notification (`12`)** and **deletion (`13`)** flows.
- **Demonstration SQLite model** with schema, seed data, and automated checks; includes `app1/channel1/dr1/sub1`.
- REST contracts, discovery, JSON and cURL examples, technology stack analysis, and delivery guidance retained from v1.
- New files covering **architectural rationale**, **DTOs**, **naming/cascade policies**, **traceability**, a **changelog**, and a **glossary**.

## Where to start

1. `docs/17-justificacao-modelacao.md` — why the architecture is designed this way.
2. `docs/diagramas/01-diagrama-classes.md` and `02-diagrama-er.md` — domain versus SQLite.
3. `docs/diagramas/03-arquitetura-componentes.md`, `10-diagrama-servicos.md`, `11-diagrama-dtos.md` — responsibilities and DTOs.
4. `docs/18-contratos-dto-e-mapeamento.md` — explanation of `res-type`.
5. `docs/19-politica-nomes-e-cascatas.md`, `docs/13-duvidas-e-decisoes.md` — **provisional** decisions and questions about the brief.
6. `docs/20-matriz-rastreabilidade-v2.md` and `docs/21-changelog-v2.md` — traceability and changes.

## Documentation index

| Group | Files |
|---|---|
| Source | `docs/00-enunciado-original.txt` (original brief, with Portuguese headings translated) |
| Core | `docs/01` through `docs/16` (requirements, domain, persistence, REST, discovery, events, scenario, cURL, tests, stack, delivery, OpenAPI, ADRs, XML/XSD) |
| v2 additions | `docs/17` rationale, `18` DTOs, `19` uniqueness and cascades, `20` traceability, `21` changelog, `22` glossary |
| UML/flows | `docs/diagramas/01` through `13`, in `.md` and `.mmd` |
| SQLite | `sql/schema.sql`, `sql/seed.sql`, `data/solid-modelo-exemplo.db` |
| XML | `exemplos/valve-notifications-example.xml`, `exemplos/valve-notifications.xsd` |
| Checks | `tests/test_sqlite_model.py` (**SQLite model** test, not service tests) |

## Certainty labels

- **[REQUIREMENT]**: comes from the supplied assignment brief.
- **[PROPOSAL]**: a **reversible** modeling choice.
- **[QUESTION]**: a gap or inconsistency needing clarification.
- `SOL-Fxx`: an **internal traceability** identifier, not assigned by the instructor.

## Fixed compliance constraints

.NET 10, SQLite, URL `/api/solid`, port 8765, exact public JSON property names, discovery using `solid-discovery`, virtual `/subs` node, no `GET all`, REST/JSON, HTTP/MQTT events, Swagger/OpenAPI, Sensor/Valve scenario, and XML/XSD. §6: only technologies taught in practical classes. Questions Q-01/Q-02/Q-03/Q-05/Q-08/Q-14 **are not** approved decisions.

**Important:** the `.db` file is only a prototyping artifact. This package does not include a working implementation of the middleware/Valve/Sensor or evidence of instructor approval.
